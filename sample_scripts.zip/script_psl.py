#!/usr/bin/env python

import grass.script as gscript      # import the Python Scripting Library

def main():
    startday = 1    # the Julian date when to start the computations
    endday = 31     # the Julian date when to end the computations
    basename = "psl_clear_GHI"      # basename of the created solar radiation maps
    output = "psl_clear_GHI_ave"    # name of the average map
    calc = ""   # variable to hold the mapcalc calculation

    for day in range(startday, endday+1):   # run r.sun from startday to endday

        ghi = "{}_{}".format(basename, day)    # create a new name for the output ghi map

        gscript.run_command('r.sun', elevation='elev', aspect='aspect', 
            slope='slope', linke='linke_Jan',horizon_basename='horizon', 
            horizon_step='15', glob_rad=ghi, day=day)   # run r.sun

    '''Create the mapcalc calculation string'''
    for day in range(startday, endday):
        calc += "{}_{} + ".format(basename, day)

    calc += "{}_{}".format(basename, endday)

    gscript.mapcalc('{} = {}'.format(output, calc))     # Perform the mapcalc


if __name__ == "__main__":
    main()
