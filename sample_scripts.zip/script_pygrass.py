#!/usr/bin/env python

from grass.pygrass.modules import Module    # import Module from PyGRASS

r_sun = Module('r.sun')     # r_sun is the r.sun module
r_mapcalc = Module('r.mapcalc')     #r_mapcalc is the r.mapcalc module

def main():
    startday = 1    # the Julian date when to start the computations
    endday = 31     # the Julian date when to end the computations
    basename = "pygrass_clear_GHI"      # basename of the created solar radiation maps
    output = "pygrass_clear_GHI_ave"    # name of the average map
    calc = ""   # variable to hold the mapcalc calculation

    for day in range(startday, endday+1):   # run r.sun from startday to endday

        ghi = "{}_{}".format(basename, day)    # create a new name for the output ghi map

        r_sun(elevation='elev', aspect='aspect', slope='slope', 
            linke='linke_Jan', horizon_basename='horizon', horizon_step='15', 
            glob_rad=ghi, day=day, verbose=True, overwrite=True)    # run r.sun

    '''Create the mapcalc calculation string'''
    for day in range(startday, endday):
        calc += "{}_{} + ".format(basename, day)

    calc += "{}_{}".format(basename, endday)

    r_mapcalc(expression="{} = {}".format(output, calc))


if __name__ == "__main__":
    main()
