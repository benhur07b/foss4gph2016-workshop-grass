#!/usr/bin/env python

'''This script doesn't work when run from the terminal. 
It must be run from File -> Launch script menu'''

'''The parts below define the module interface.'''
#%module
#% description: Computes daily solar radiation from start day to end day and averages them
#% keyword: raster
#% keyword: r.sun
#% keyword: average
#%end
#%option
#% key: startday
#% type: integer
#% description: The Julian day to start computations
#% required : yes
#% answer: 1
#%end
#%option
#% key: endday
#% type: integer
#% description: The Julian day to stop computations
#% required : yes
#% answer: 31
#%end
#%option
#% key: basename
#% type: string
#% description: basename for daily GHI maps
#% required : no
#% answer: clear_GHI
#%end
#%option
#% key: output
#% type: string
#% description: The name of the output average raster
#% required : no
#% answer: clear_GHI_ave
#%end


import sys
import grass.script as gscript      # import the Python Scripting Library
from grass.pygrass.modules import Module    # import Module from PyGRASS

r_sun = Module('r.sun')     # r_sun is the r.sun module
r_mapcalc = Module('r.mapcalc')     #r_mapcalc is the r.mapcalc module

def main():
    '''Set options (correspongs to the options stated above)'''
    startday = int(options['startday'])     # the Julian date when to start the computations
    endday = int(options['endday'])         # the Julian date when to end the computations 
    basename = options['basename']          # basename of the created solar radiation maps
    output = options['output']              # name of the average map
    calc = ""   # variable to hold the mapcalc calculation

    for day in range(startday, endday+1):   # run r.sun from startday to endday

        ghi = "{}_{}".format(basename, day)    # create a new name for the output ghi map

        r_sun(elevation='elev', aspect='aspect', slope='slope', 
            linke='linke_Jan', horizon_basename='horizon', horizon_step='15', 
            glob_rad=ghi, day=day, verbose=True, overwrite=True)    #run r.sun

    '''Create the mapcalc calculation string'''
    for day in range(startday, endday):
        calc += "{}_{} + ".format(basename, day)

    calc += "{}_{}".format(basename, endday)

    r_mapcalc(expression="{} = {}".format(output, calc))


if __name__ == "__main__":
    options, flags = gscript.parser()
    main()
